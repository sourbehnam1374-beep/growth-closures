# κ-correspondence v1 — artifact

One-command kernel check (Lean 4.30.0):
    lean GrowthClosure_kappa.lean        # expect exit 0; 33 declarations audited; no sorry, no mathlib

Executable verification:
    python3 verify_o1_necessity.py       # exhaustive: 5-record stores x 2^4 deletions + conservation n=3..8
    python3 verify_unified.py            # 7/7 determination schemas vs reference implementation
    python3 corpus_o5.py                 # price-of-deniability numbers (requires moby.txt; see header)

Paper: kappa_paper_v1.pdf (build: xelatex x2). Sweep: prior_art_kappa_round2.md.
