#!/usr/bin/env python3
"""bench_delete.py -- Empirics for the deletion paper.

PART A (timing): identical data model to bench_growth.py (cohort-capped
random corpora, cap 5; growing base; fixed D of 20 random atoms;
median-of-5 wall time). Measures (a) epoch re-closure K(S\\D) from
scratch vs (b) cone excision of the precomputed K(S). Fingerprint
equality asserted at every size (the cone theorem, live).

PART B (corpus): single-atom deletion analytics on the Moby-Dick cohort
distribution (Gutenberg #2701, identical tokenization to
corpus_cohorts.py; summary stats cross-checked against the committed
corpus_stats.json). For every atom: the complete-semantics cone size
(exact integer combinatorics) vs the materialized quotient-view cone
(removals + insertions). The per-cohort mechanics are verified live on
an executed closure before the analytic model is trusted.
"""
import collections
import json
import math
import re
import random
import statistics
import time
import urllib.request

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import growth_check as gc
import delete_growth as dg

COHORT_CAP = 5
DEL_N = 20
BASES = [250, 500, 1000, 2000, 4000, 8000]
REPS = 5

URL = "https://www.gutenberg.org/files/2701/2701-0.txt"
STOP = set("""the a an and or but of to in on at by for with from as is are was were be been
being it its this that these those he she they we you i his her their our your my me him them
us not no nor so if then than there here when where which who whom what all any some such own
same very can will just do does did done have has had may might must shall should would could
about into over under again further once more most other only out up down off above below""".split())


def make_atoms(n, start):
    return [gc.atom("p%d" % i, "D%d" % (i // COHORT_CAP)) for i in range(start, start + n)]


# ----------------------------------------------------------------------
# PART A -- timing
# ----------------------------------------------------------------------
def part_a():
    rows = []
    rnd = random.Random(0)
    for nb in BASES:
        base = make_atoms(nb, 0)
        D = {a["addr"] for a in rnd.sample(base, DEL_N)}
        pS, gS = gc.close_field(base)                    # outside the timer
        te, tx = [], []
        for _ in range(REPS):
            t0 = time.perf_counter(); dg.epoch(pS, D);   te.append(time.perf_counter() - t0)
            t0 = time.perf_counter(); dg.excise(pS, D);  tx.append(time.perf_counter() - t0)
        kp, kg, _ = dg.excise(pS, D)
        ep, eg = dg.epoch(pS, D)
        assert gc.canonical(kp, kg)[0] == gc.canonical(ep, eg)[0]
        row = {"n": nb,
               "t_epoch": statistics.median(te),
               "t_excise": statistics.median(tx),
               "speedup": statistics.median(te) / statistics.median(tx)}
        rows.append(row)
        print("n=%5d  epoch %.4fs  excise %.4fs  speedup %.1fx  [fp equal]" %
              (nb, row["t_epoch"], row["t_excise"], row["speedup"]))
    return rows


# ----------------------------------------------------------------------
# PART B -- corpus deletion analytics
# ----------------------------------------------------------------------
def cohort_sizes():
    raw = urllib.request.urlopen(URL, timeout=60).read().decode("utf-8", "replace")
    s = raw.find("*** START"); e = raw.find("*** END")
    body = raw[raw.find("\n", s):e] if s != -1 and e != -1 else raw
    sentences = [t.strip() for t in re.split(r"[.!?]+", body) if len(t.strip()) >= 20]
    coh = collections.Counter()
    for sent in sentences:
        words = [w for w in re.findall(r"[a-z]+", sent.lower())
                 if len(w) >= 3 and w not in STOP]
        if not words:
            continue
        freq = collections.Counter(words)
        coh[sorted(freq.items(), key=lambda kv: (-kv[1], kv[0]))[0][0]] += 1
    return sorted(coh.values(), reverse=True)


def verify_mechanics():
    """Execute one real cohort deletion and check the analytic model:
    materialized cone (quotient view) of one atom in a bindable cohort
    of size n>=4 is exactly 4 removals (atom + maximal block + section +
    root) and exactly 3 insertions (the n-1 chain)."""
    cohort = [gc.atom("c-%d" % i, "W") for i in range(6)]
    noise = [gc.atom("z-%d" % i, "N%d" % i) for i in range(4)]
    parts, gov = gc.close_field(cohort + noise)
    q_before, _ = gc.quotient_view(parts)
    kept, kg, _ = dg.excise(parts, {cohort[0]["addr"]})
    q_after, _ = gc.quotient_view(kept)
    removed = set(q_before) - set(q_after)
    inserted = set(q_after) - set(q_before)
    assert len(removed) == 4 and len(inserted) == 3, (len(removed), len(inserted))
    # and for n == 3 the cohort dies: 4 removals, 0 insertions
    tri = [gc.atom("t-%d" % i, "V") for i in range(3)]
    p2, g2 = gc.close_field(tri + noise)
    qb, _ = gc.quotient_view(p2)
    k2, kg2, _ = dg.excise(p2, {tri[0]["addr"]})
    qa, _ = gc.quotient_view(k2)
    assert len(set(qb) - set(qa)) == 4 and len(set(qa) - set(qb)) == 0
    print("mechanics verified live: n>=4 -> 4 removed / 3 inserted ; "
          "n==3 -> 4 removed / 0 inserted")


def part_b():
    sizes = cohort_sizes()
    n_atoms, n_desc = sum(sizes), len(sizes)
    bindable = [n for n in sizes if n >= 3]
    covered = sum(bindable)
    stats = json.load(open("../paper/figures/corpus_stats.json"))
    assert (n_atoms, n_desc, len(bindable), covered, max(sizes)) == \
           (stats["atoms"], stats["desc"], stats["bindable"],
            stats["covered"], stats["nmax"]), "corpus drifted from committed stats"
    print("corpus cross-check vs corpus_stats.json: OK "
          "(%d atoms, %d desc, %d bindable, nmax=%d)" %
          (n_atoms, n_desc, len(bindable), max(sizes)))

    verify_mechanics()

    # exact complete-semantics cone for one atom in a cohort of size n:
    # blocks containing it: f(n) = sum_{m=3..n} C(n-1, m-1); each cone
    # block carries its own section and root -> cone = 1 + 3*f(n)
    def f_blocks(n):
        return sum(math.comb(n - 1, m - 1) for m in range(3, n + 1))

    per_atom = []          # (n, complete_cone, mat_removed, mat_inserted)
    for n in sizes:
        if n >= 4:
            rec = (n, 1 + 3 * f_blocks(n), 4, 3)
        elif n == 3:
            rec = (n, 1 + 3 * f_blocks(n), 4, 0)
        else:
            rec = (n, 1, 1, 0)
        per_atom.extend([rec] * n)
    assert len(per_atom) == n_atoms

    worst = max(per_atom, key=lambda r: r[1])
    log10_worst = math.log10(worst[1])
    anomaly = sum(1 for r in per_atom if r[3] > 0)
    mat_cones = [r[2] for r in per_atom]
    out = {
        "atoms": n_atoms,
        "anomaly_count": anomaly,
        "anomaly_frac": anomaly / n_atoms,
        "worst_n": worst[0],
        "worst_complete_cone_log10": log10_worst,
        "mat_cone_mean": statistics.mean(mat_cones),
        "mat_cone_median": statistics.median(mat_cones),
        "mat_cone_max": max(mat_cones),
        "frac_in_bindable": sum(1 for r in per_atom if r[0] >= 3) / n_atoms,
    }
    print("single-atom deletion over all %d atoms:" % n_atoms)
    print("  view-insertion (anomaly) on deletion : %d atoms  (%.1f%%)"
          % (anomaly, 100 * out["anomaly_frac"]))
    print("  worst complete-semantics cone        : n=%d -> ~10^%.2f parts"
          % (worst[0], log10_worst))
    print("  materialized quotient cone           : mean %.2f, median %d, max %d"
          % (out["mat_cone_mean"], out["mat_cone_median"], out["mat_cone_max"]))
    return sizes, per_atom, out


# ----------------------------------------------------------------------
# Figures
# ----------------------------------------------------------------------
def figures(rows, sizes, per_atom):
    # Fig 1: epoch vs excision timing
    fig, ax = plt.subplots(figsize=(5.4, 3.4))
    ns = [r["n"] for r in rows]
    ax.loglog(ns, [r["t_epoch"] for r in rows], "o-", label="epoch re-closure $K(S\\setminus D)$")
    ax.loglog(ns, [r["t_excise"] for r in rows], "s-", label="cone excision of $K(S)$")
    ax.set_xlabel("base atoms $|S|$")
    ax.set_ylabel("median wall time (s), $|D|=20$")
    ax.legend(frameon=False, fontsize=8)
    ax.grid(True, which="both", lw=0.3, alpha=0.4)
    fig.tight_layout()
    fig.savefig("../paper2/figures/fig_delete_bench.pdf")
    fig.savefig("../paper2/figures/fig_delete_bench.png", dpi=180)

    # Fig 2: complete vs materialized cone per cohort size
    fig2, ax2 = plt.subplots(figsize=(5.4, 3.4))
    uniq = sorted(set(s for s in sizes if s >= 3))
    comp = [math.log10(1 + 3 * sum(math.comb(n - 1, m - 1) for m in range(3, n + 1)))
            for n in uniq]
    ax2.plot(uniq, comp, "o-", ms=3, label="complete-semantics cone (log$_{10}$ parts)")
    ax2.axhline(math.log10(4), color="tab:red", ls="--", lw=1,
                label="materialized quotient cone (4 parts)")
    ax2.set_xscale("log")
    ax2.set_xlabel("cohort size $n$ of the deleted atom")
    ax2.set_ylabel("log$_{10}$ cone size")
    ax2.legend(frameon=False, fontsize=8)
    ax2.grid(True, which="both", lw=0.3, alpha=0.4)
    fig2.tight_layout()
    fig2.savefig("../paper2/figures/fig_delete_cone.pdf")
    fig2.savefig("../paper2/figures/fig_delete_cone.png", dpi=180)


def main():
    import os
    os.makedirs("../paper2/figures", exist_ok=True)
    print("== PART A: epoch vs excision =="); rows = part_a()
    print("== PART B: corpus single-atom deletion =="); sizes, per_atom, out = part_b()
    figures(rows, sizes, per_atom)
    json.dump(rows, open("../paper2/figures/delete_rows.json", "w"), indent=1)
    json.dump(out, open("../paper2/figures/corpus_delete.json", "w"), indent=1)
    print("figures + JSON written to ../paper2/figures/")


if __name__ == "__main__":
    main()
