Ancillary files for "Principled Deletion in Content-Addressed Rule Closures"
(companion paper: "Monotone Growth of Content-Addressed Rule Closures").

  growth_check.py            base closure implementation (pure stdlib)
  delete_growth.py           deletion module; 12-item ledger (run: python3 delete_growth.py)
  test_delete_properties.py  10 randomized properties (run: python3 -m pytest, needs hypothesis)
  bench_delete.py            epoch-vs-excision benchmark + corpus deletion analytics
  delete_rows.json           benchmark rows as committed
  corpus_delete.json         corpus deletion analytics as committed
  GrowthClosure.lean         self-contained Lean 4 development incl. namespace
                             Growth.Deletion (lean GrowthClosure.lean; no mathlib)
  VERIFICATION.md            the claim ladder for both papers

delete_growth.py imports growth_check.py; keep them in one directory.

[v1.1] Adds Theorem 9 (anomaly characterization); verifier: test_anomaly_characterization.py (698 randomized instances + corpus identity 5014/8631). anc/GrowthClosure.lean is the full trilogy development.
