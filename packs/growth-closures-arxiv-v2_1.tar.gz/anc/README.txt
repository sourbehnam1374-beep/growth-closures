Ancillary files for "Monotone Growth of Content-Addressed Rule Closures" (v2.1)
Author: Behnam Sour (ORCID 0009-0002-3176-1956)

growth_check.py            reference implementation + 15-check ledger (pure Python 3 stdlib)
                           run: python3 growth_check.py        -> expects 15/15 PASS
test_growth_properties.py  randomized property suite, 14 properties x 60 instances
                           run: pip install hypothesis && python3 -m pytest test_growth_properties.py
GrowthClosure.lean         self-contained Lean 4 formalization (no imports, no sorry,
                           no Classical.choice) — full closure algebra INCLUDING Theorem 4
                           (semi-naive frontier locality over the concrete RuleFamily format)
                           and the H1/H2 discharge theorems (step_finitary, step_mono,
                           both axiom-free); check: lean GrowthClosure.lean  (Lean 4.30.0)
bench_growth.py            Section 8.1 benchmark (requires matplotlib + growth_check.py)
corpus_cohorts.py          Section 8.2 corpus experiment (network: Project Gutenberg #2701)
VERIFICATION.md            three-rung verification report with verbatim axiom audit

Repository: https://github.com/sourbehnam1374-beep/growth-closures

[v2.1] anc/GrowthClosure.lean is the full trilogy development (Necessity/Epoch/Unified namespaces included; audit lines for this paper unchanged).
